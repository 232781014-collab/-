/**
 * 内容引擎 · 后端代理
 * 中转站：https://bobdong.cn/v1
 * 文字生成：/v1/chat/completions（OpenAI 兼容）
 * 图片生成：/v1/responses（OpenAI Responses API）
 */

const http = require('http');
const https = require('https');
const url = require('url');

const PORT = 3001;
const API_KEY = process.env.OPENAI_API_KEY || process.env.ANTHROPIC_API_KEY || '';
const BASE_HOST = 'bobdong.cn';
const BASE_PATH = '/v1';

// 文字模型（灵感创作 / 诊断）
const TEXT_MODEL = 'gpt-4o';
// 图片模型（图片工坊）
const IMAGE_MODEL = 'gpt-image-1';

if (!API_KEY) {
  console.error('❌ 缺少 API Key');
  console.error('   请运行：export OPENAI_API_KEY=sk-xxxx');
  process.exit(1);
}

/* ══════════════════════════════════════════
   核心请求函数
══════════════════════════════════════════ */

/** 文字生成：OpenAI Chat Completions 格式 */
function chatCompletion(messages, opts = {}) {
  const body = JSON.stringify({
    model: opts.model || TEXT_MODEL,
    max_tokens: opts.maxTokens || 2000,
    temperature: opts.temperature ?? 0.7,
    messages,
  });
  return httpsPost(`${BASE_PATH}/chat/completions`, body);
}

/** 图片生成：OpenAI Responses API 格式 */
function generateImage(prompt, inputImageBase64 = null, opts = {}) {
  const contentArr = [];

  // 如果有参考图，先加图片
  if (inputImageBase64) {
    // 去掉 data:image/xxx;base64, 前缀（如果有）
    const base64Data = inputImageBase64.replace(/^data:image\/\w+;base64,/, '');
    contentArr.push({
      type: 'input_image',
      image_url: `data:image/jpeg;base64,${base64Data}`,
    });
  }

  contentArr.push({ type: 'input_text', text: prompt });

  const body = JSON.stringify({
    model: opts.model || IMAGE_MODEL,
    input: [{ role: 'user', content: contentArr }],
    modalities: ['image'],
    // 可根据中转站支持情况调整
    // size: opts.size || '1024x1024',
  });

  return httpsPost(`${BASE_PATH}/responses`, body);
}

/** 底层 HTTPS 请求 */
function httpsPost(path, body) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: BASE_HOST,
      port: 443,
      path,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        'Authorization': `Bearer ${API_KEY}`,
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (res.statusCode >= 400) {
            reject(new Error(`API 错误 ${res.statusCode}: ${parsed.error?.message || data.slice(0, 200)}`));
          } else {
            resolve(parsed);
          }
        } catch (e) {
          reject(new Error('响应解析失败: ' + data.slice(0, 300)));
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(60000, () => { req.destroy(); reject(new Error('请求超时 60s')); });
    req.write(body);
    req.end();
  });
}

/** 从 ChatCompletion 响应中提取文字 */
function extractText(res) {
  return res?.choices?.[0]?.message?.content || '';
}

/** 从 Responses API 响应中提取图片 base64 */
function extractImage(res) {
  const output = res?.output || [];
  for (const item of output) {
    if (item.type === 'image_generation_call' && item.result) return item.result;
    if (item.type === 'message') {
      for (const c of item.content || []) {
        if (c.type === 'image_url') return c.image_url?.url || c.image_url;
        if (c.type === 'image' && c.image?.url) return c.image.url;
      }
    }
  }
  return null;
}

/* ══════════════════════════════════════════
   路由处理
══════════════════════════════════════════ */

const routes = {

  /* ── 灵感创作：生成 3 个原创版本 ── */
  'POST /api/generate-content': async ({ inputData, srcPlat, dstPlat, prodName,
    prodFeature, prodTone, angle, tone, industryName }) => {

    const platLogic = {
      xiaohongshu: '种草信任感·搜索关键词前置·收藏率优先·闺蜜语气·痛点共鸣',
      douyin:      '前3秒强钩子·完播率优先·快节奏·视觉冲击·反转结构',
      shipinhao:   '社交裂变·熟人信任·分享价值·情感共鸣·私域引流',
      gongzhonghao:'深度内容·成交转化·SEO关键词·打开率优先',
      weibo:       '热搜借势·话题营销·引发转发讨论',
    }[dstPlat] || '适合目标平台的内容逻辑';

    const prompt = `你是内容引擎的AI创作助手，专门帮助品牌运营人员把灵感内容转化为原创内容。

## 灵感内容
${inputData?.content || inputData?.url || '（用户提供的灵感素材）'}

## 任务
- 来源平台：${srcPlat}，目标平台：${dstPlat}（逻辑：${platLogic}）
- 产品：${prodName}，卖点：${prodFeature || '暂未填写'}
- 品牌语气：${prodTone || '自然真实'}，营销角度：${angle || '常规种草'}，文案语气：${tone || '闺蜜推荐'}
- 行业：${industryName || '服装'}

## 要求
基于灵感内容的创作框架（钩子/情绪弧线/叙事节奏）重新创作，借鉴逻辑，产出原创。
生成 3 个不同角度的版本，返回纯 JSON：
{
  "framework":{"hookType":"","emotionArc":"","platformLogic":"","ctaStrategy":""},
  "versions":[
    {"angle":"情感种草型","title":"","content":"","tags":"","score":78,"tip":""},
    {"angle":"干货攻略型","title":"","content":"","tags":"","score":83,"tip":""},
    {"angle":"故事叙事型","title":"","content":"","tags":"","score":75,"tip":""}
  ]
}`;

    const res = await chatCompletion([{ role: 'user', content: prompt }]);
    const text = extractText(res);
    try {
      const clean = text.replace(/```json|```/g, '').trim();
      return { ok: true, data: JSON.parse(clean) };
    } catch {
      return { ok: false, error: 'JSON解析失败', raw: text.slice(0, 500) };
    }
  },

  /* ── 爆款诊断：5 Agent 数据 ── */
  'POST /api/diagnose': async ({ title, content, tags, category, platform, type, baselineInsight }) => {
    const prompt = `你是小红书/抖音内容诊断专家，基于874条真实爆款数据进行专业诊断。

## 待诊断内容
平台：${platform}，形式：${type === 'video' ? '视频脚本' : '图文笔记'}，品类：${category}
标题：${title || '未填写'}
正文：${content}
标签：${tags || '未填写'}
品类洞察：${baselineInsight}

## 要求
从5个维度诊断，模拟5个AI Agent的视角，返回纯JSON：
{
  "agents":{
    "content":{"score":65,"r1":"内容分析师第1轮（具体问题2-3句）","r2":"第2轮（引用其他角色后的补充或修正）"},
    "visual":{"score":70,"r1":"视觉诊断师第1轮","r2":"第2轮"},
    "growth":{"score":58,"r1":"增长策略师第1轮（钩子/CTA）","r2":"第2轮"},
    "user":{"score":62,"r1":"用户模拟器第1轮（停留/共鸣）","r2":"第2轮（可主动调整自己分数）"}
  },
  "judge":{
    "finalScore":64,
    "verdict":"综合裁判最终判定（主要短板+优化优先级，3-4句）",
    "priorities":[
      {"title":"问题一","desc":"改进建议"},
      {"title":"问题二","desc":"改进建议"},
      {"title":"问题三","desc":"改进建议"}
    ]
  }
}`;

    const res = await chatCompletion([{ role: 'user', content: prompt }], { maxTokens: 1500 });
    const text = extractText(res);
    try {
      const clean = text.replace(/```json|```/g, '').trim();
      return { ok: true, data: JSON.parse(clean) };
    } catch {
      return { ok: false, error: 'JSON解析失败', raw: text.slice(0, 500) };
    }
  },

  /* ── 图片工坊：AI 图片生成 ── */
  'POST /api/generate-image': async ({ tool, params, imageBase64, ratio }) => {
    // 根据工具类型构建 Prompt
    const promptMap = {
      model: `你是一位专业商业摄影师。这是一件服装的产品图，请生成一张${params.modelType || '亚洲清新'}风格的模特上身效果图。
场景：${params.scene || '工作室纯色'}，姿势：${params.pose || '正面站立'}，年龄：${params.age || '25-30岁'}。
要求：高品质商业摄影风格，服装细节清晰，比例为 ${ratio || '3:4'}。`,

      scene: `你是一位专业商业摄影师。这是一件商品的产品图，请将它放置在${params.package || '生活方式'}风格的场景中。
光影：${params.light || '自然日光'}，比例：${ratio || '3:4'}。
要求：高品质电商展示图，商品突出，场景真实自然。`,

      bg: `请对这张图片进行背景替换。
新背景：${params.bgType || '纯色背景'}，颜色调性：${params.bgColor || '奶白/米色'}，光线：${params.light || '自然光'}。
要求：抠图干净，边缘自然，与新背景融合协调。`,

      style: `请将这张图片转换为${params.targetStyle || '法式复古'}风格。
迁移强度：${params.intensity || '中度（推荐）'}。
要求：保留主体内容，改变整体视觉风格，保持画面协调。`,

      enhance: `请对这张图片进行专业修图处理。
修图模式：${params.mode || '商业精修（去瑕疵+提亮）'}，画质提升：${params.upscale || '2x'}。
要求：提升画质，修复瑕疵，色彩自然，适合商业发布。`,

      text: `请生成一张创意文字设计图。
设计类型：${params.designType || 'T恤印花'}，文字内容：「${params.textContent || 'Content'}」。
字体风格：${params.fontStyle || '现代无衬线'}，配色方案：${params.colorScheme || '莫兰迪柔色'}。
比例：${ratio || '1:1'}，要求：适合商业使用，设计感强，清晰可辨。`,

      color: `请为这件产品生成${params.colorCount || 6}套不同配色版本。
配色风格：${params.colorStyle || '莫兰迪柔色系'}。
要求：保留产品款式和设计，只改变颜色，每套配色协调美观。`,

      expand: `请对这张图片进行智能扩图，将比例调整为 ${ratio || '9:16'}。
扩图方向：${params.direction || '上下扩展'}，背景风格与原图保持一致。
要求：扩展内容自然，无明显接缝，适合 ${ratio || '9:16'} 平台发布。`,
    };

    const prompt = promptMap[tool] || `请对这张图片进行AI处理，比例为 ${ratio || '1:1'}。`;

    try {
      const res = await generateImage(prompt, imageBase64 || null, { size: '1024x1024' });
      const imgData = extractImage(res);
      if (imgData) {
        return { ok: true, imageData: imgData, prompt };
      } else {
        // 如果提取不到图片，返回原始响应供调试
        return { ok: false, error: '未能提取图片数据', debug: JSON.stringify(res).slice(0, 500) };
      }
    } catch (err) {
      return { ok: false, error: err.message };
    }
  },

  /* ── 通用对话（透传）── */
  'POST /api/chat': async ({ messages, model, maxTokens }) => {
    const res = await chatCompletion(messages, { model, maxTokens });
    return { ok: true, text: extractText(res), raw: res };
  },
};

/* ══════════════════════════════════════════
   HTTP 服务
══════════════════════════════════════════ */

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  const { pathname } = url.parse(req.url);
  const routeKey = `${req.method} ${pathname}`;

  if (routeKey === 'GET /health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      message: '内容引擎后端运行中 🚀',
      relay: `https://${BASE_HOST}${BASE_PATH}`,
      textModel: TEXT_MODEL,
      imageModel: IMAGE_MODEL,
    }));
    return;
  }

  const handler = routes[routeKey];
  if (!handler) {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: `路由不存在: ${routeKey}` }));
    return;
  }

  let body = '';
  req.on('data', chunk => body += chunk);
  req.on('end', async () => {
    try {
      const parsed = body ? JSON.parse(body) : {};
      const start = Date.now();
      console.log(`→ ${routeKey}`);
      const result = await handler(parsed);
      console.log(`← ${routeKey} ${Date.now() - start}ms ${result.ok ? '✓' : '✗'}`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result));
    } catch (err) {
      console.error(`✗ ${routeKey}:`, err.message);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: err.message }));
    }
  });
});

server.listen(PORT, () => {
  console.log(`\n🚀 内容引擎后端代理`);
  console.log(`   本地地址：http://localhost:${PORT}`);
  console.log(`   中转站：https://${BASE_HOST}${BASE_PATH}`);
  console.log(`   文字模型：${TEXT_MODEL}`);
  console.log(`   图片模型：${IMAGE_MODEL}`);
  console.log(`\n   接口：`);
  console.log(`   POST /api/generate-content  灵感创作`);
  console.log(`   POST /api/diagnose           爆款诊断`);
  console.log(`   POST /api/generate-image     图片工坊`);
  console.log(`   POST /api/chat               通用对话`);
  console.log(`   GET  /health                 健康检查\n`);
});
